#   Prepare Python Env
-   If use pipenv
    `pipenv install`

-   If use pip
    `pip install -r requirements.txt`