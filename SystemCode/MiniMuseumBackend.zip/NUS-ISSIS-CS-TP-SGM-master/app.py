import logging
from flask import Flask
from flask_assistant import Assistant
from flask_assistant import ask, tell, event, build_item
from flask_assistant import context_manager
from IntentHandler.MuseumDetail import *
from IntentHandler.SupportDetail import *
from IntentHandler.RecommendActivity import *
from IntentHandler.ExhibitionDetail import *
from IntentHandler.ProgrammeDetail import *
from IntentHandler.DiningDetail import *
from IntentHandler.RetailDetail import *
from IntentHandler.utils.NameUtil import abbrName


app = Flask(__name__)
app.config['INTEGRATIONS'] = ['ACTIONS_ON_GOOGLE']
assist = Assistant(app, route='/', project_id="minimuseum-snpwlr")


@assist.action("getMuseumDetail")
def getMuseumDetail(museum, option):
    response = getMuseumIntroDao(museum)
    return response


@assist.action("getMuseumOpenTime")
def getMuseumOpenTime(museum, time):
    response = getMuseumOpenTimeDao(museum, time)
    return response

@assist.action("getMuseumTimeNC")
def getMuseumTimeNC(museum, time):
    response = getMuseumOpenTimeDao(museum, time)
    return response


@assist.action("getMuseumLocation")
def getMuseumLocation(museum, location):
    response = getMuseumLocationDao(museum, location)
    return response

@assist.action("getMuseumLocationNC")
def getMuseumLocationNC(museum, location):
    response = getMuseumLocationDao(museum, location)
    return response

@assist.action("getMuseumTicketInfo")
def getMuseumTicketInfo(museum, price):
    response = getMuseumTicketInfoDao(museum, price)
    return response

@assist.action("getMuseumTicketNC")
def getMuseumTicketNC(museum, price):
    response = getMuseumTicketInfoDao(museum, price)
    return response

@assist.action("getMuseumGuidedTourInfo")
def getMuseumGuidedTourInfo(museum, guidedtours):
    response = getMuseumGuidedTourInfoDao(museum, guidedtours)
    return response


@assist.action("getMuseumGroupVisits")
def getMuseumGroupVisits(museum, groupvisits):
    response = getMuseumGroupVisitsDao(museum, groupvisits)
    return response


@assist.action("getMuseumAmenitiesandEtiquetteInfo")
def getMuseumAmenitiesandEtiquetteInfo(museum, amenities):
    response = getMuseumAmenitiesandEtiquetteInfoDao(museum, amenities)
    return response


@assist.action("getMuseumVenueRentalInfo")
def getMuseumVenueRentalInfo(museum, venuerental):
    response = getMuseumVenueRentalInfoDao(museum, venuerental)
    return response


@assist.action("getMuseumAccessibilityInfo")
def getMuseumAccessibilityInfo(museum, accessibility):
    response = getMuseumAccessibilityInfoDao(museum, accessibility)
    return response


@assist.action("getMuseumPhotographyAndFilmingInfo")
def getMuseumPhotographyAndFilmingInfo(museum, photography):
    response = getMuseumPhotographyAndFilmingInfoDao(museum, photography)
    return response

# support
@assist.action("getSupportDetail")
def getSupportDetail(support, supporttype):
    response = getSupportDetailDao(support, supporttype)
    return response


@assist.prompt_for('supporttype', intent_name='getSupportDetail')
def prompt_supporttype(supporttype):
    speech = "can you tell what kind of support do you want to do ? Individual or Corporate"
    return ask(speech).suggest("Individual", "Corporate")


@assist.prompt_for('support', intent_name='getSupportDetail')
def prompt_support(support, supporttype):
    response = getSupportDetailDao(support, supporttype)
    return response


@assist.action("getVolunteerInfo")
def getVolunteerInfo(volunteer):
    response = getVolunteerInfoDao(volunteer)
    return response


@assist.action("getFellowshipInfo")
def getFellowshipInfo(fellowship):
    speech = getFellowshipInfoDao(fellowship)
    return speech


# recommend
@assist.action('getRecommendInfo')
def getRecommendInfo(recommendGroupType, recommendActivityType, date_period, date, price):
    if recommendGroupType == "" and recommendActivityType == "":
        speech = "Of course,But What type of activity do you want me to recommend? For family? Is a Workshop ?"
        return ask(speech).suggest("Family Fun", "Workshop")
    if date_period == "" and date == "":
        speech = "Well you didn't mention when you want to go? Today ? Tomorrow ? This weekends ?"
        return ask(speech).suggest("Today", "Tomorrow", "This weekends")
    if price == "":
        speech = "Last but not least, Do you mind the activity is not free?"
        return ask(speech).suggest("No", "Yes")
    context_manager.clear_all()
    return getRecommonendList(recommendGroupType=recommendGroupType,
                              recommendActivityType=recommendActivityType,
                              date=date,
                              date_period=date_period, price=price)


@assist.action('getRecommendInfo_GroupType')
def getRecommendInfo_GroupType(recommendGroupType, date_period, date, price):
    if date_period == "" and date == "":
        speech = "Well you didn't mention when you want to go? Today ? Tomorrow ? This weekends ?"
        return ask(speech).suggest("Today", "Tomorrow", "This weekends")
    if price == "":
        speech = "Last but not least, Do you mind the activity is not free?"
        return ask(speech).suggest("No", "Yes")
    context_manager.clear_all()
    return getRecommonendList(recommendGroupType=recommendGroupType,
                              date=date,
                              date_period=date_period, price=price)


@assist.action('getRecommendInfo_ActivityType')
def getRecommendInfo_ActivityType(recommendActivityType, date_period, date, price):
    if date_period == "" and date == "":
        speech = "Well you didn't mention when you want to go? Today ? Tomorrow ? This weekends ?"
        return ask(speech).suggest("Today", "Tomorrow", "This weekends")
    if price == "":
        speech = "Last but not least, Do you mind the activity is not free?"
        return ask(speech).suggest("No", "Yes")
    context_manager.clear_all()
    return getRecommonendList(recommendActivityType=recommendActivityType,
                              date=date,
                              date_period=date_period,
                              price=price)


@assist.action('getRecommendInfo_Date')
def getRecommendInfo_Date(recommendGroupType, recommendActivityType, date, price):
    if recommendGroupType == "" and recommendActivityType == "":
        speech = "Of course,But What type of activity do you want me to recommend? For family? Is a Workshop ?"
        return ask(speech).suggest("Family Fun", "Workshop")
    if price == "":
        speech = "Last but not least, Do you mind the activity is not free?"
        return ask(speech).suggest("No", "Yes")
    context_manager.clear_all()
    return getRecommonendList(recommendGroupType=recommendGroupType,
                              recommendActivityType=recommendActivityType,
                              date=date,
                              price=price)


@assist.action('getRecommendInfo_DatePeriod')
def getRecommendInfo_DatePeriod(recommendGroupType, recommendActivityType, date_period, price):
    if recommendGroupType == "" and recommendActivityType == "":
        speech = "Of course,But What type of activity do you want me to recommend? For family? Is a Workshop ?"
        return ask(speech).suggest("Family Fun", "Workshop")
    if price == "":
        speech = "Last but not least, Do you mind the activity is not free?"
        return ask(speech).suggest("No", "Yes")
    context_manager.clear_all()
    return getRecommonendList(recommendGroupType=recommendGroupType,
                              recommendActivityType=recommendActivityType,
                              date_period=date_period,
                              price=price)


@assist.action('getRecommendInfo_Price_No')
def getRecommendInfo_Price_No(recommendGroupType, recommendActivityType, date_period, date, price):
    if recommendGroupType == "" and recommendActivityType == "":
        speech = "Of course,But What type of activity do you want me to recommend? For family? Is a Workshop ?"
        return ask(speech).suggest("Family Fun", "Workshop")
    if date_period == "" and date == "":
        speech = "Well you didn't mention when you want to go? Today ? Tomorrow ? This weekends ?"
        return ask(speech).suggest("Today", "Tomorrow", "This weekends")
    context_manager.clear_all()
    return getRecommonendList(recommendGroupType=recommendGroupType,
                              recommendActivityType=recommendActivityType,
                              date=date,
                              date_period=date_period,
                              price=price)


@assist.action('getRecommendInfo_Price_Yes')
def getRecommendInfo_Price_Yes(recommendGroupType, recommendActivityType, date_period, date, price):
    if recommendGroupType == "" and recommendActivityType == "":
        speech = "Of course,But What type of activity do you want me to recommend? For family? Is a Workshop ?"
        return ask(speech).suggest("Family Fun", "Workshop")
    if date_period == "" and date == "":
        speech = "Well you didn't mention when you want to go? Today ? Tomorrow ? This weekends ?"
        return ask(speech).suggest("Today", "Tomorrow", "This weekends")
    context_manager.clear_all()
    return getRecommonendList(recommendGroupType=recommendGroupType,
                              recommendActivityType=recommendActivityType,
                              date=date,
                              date_period=date_period,
                              price=price)


@assist.action("getExhibitionIntro")
def getExhibitionIntro():
    exhlist, exhimagelist = getExhIntro()
    resp = ask(
        "Sure, there are many interesting exhibitions in our museum, mini museum find a list for you:").build_carousel()
    number = len(exhlist)
    for i in range(0, number):
        resp.add_item(
            title=exhlist[i],
            key=exhlist[i],
            img_url=exhimagelist[i],
            description=" ",
            synonyms=[exhlist[i]])

    return resp


@assist.action("getExhibitionContent")
def getExhibitionContent(exhname):
    if exhname == "":
        exhname = context_manager.get('exhibition_tap').get('OPTION')
    exhContent, exhimage, exhlink = getExhContent(exhname)
    speech = "Aha, let me see...Got it! The details about %s is showing below:" % exhname
    resp = ask(speech)
    resp.card(text=exhContent,
              title=exhname,
              img_url=exhimage,
              link=exhlink,
              link_title="click for more details"
              )
    exhnameabbr = abbrName(exhname)
    suggest1 = exhnameabbr+" time"
    suggest2 = exhnameabbr+" location"
    suggest3 = exhnameabbr + " ticket"
    context_manager.set("exhibitiondetail", "p_exhname", exhname)
    return resp.suggest(suggest1, suggest2, suggest3)


@assist.action("getExhibitionTime")
def getExhibitionTime(exhname):
    if exhname == "":
        exhname = context_manager.get_param("exhibitiondetail", "p_exhname")
    exhtime = getExhTime(exhname).lower()
    speech = "Sure, the duration of %s is %s." % (exhname, exhtime)
    exhnameabbr = abbrName(exhname)
    suggest1 = exhnameabbr+" content"
    suggest2 = exhnameabbr+" location"
    suggest3 = exhnameabbr + " ticket"
    context_manager.set("exhibitiondetail", "p_exhname", exhname)
    return ask(speech).suggest(suggest1, suggest2, suggest3)

@assist.action("getExhibitionTimeNC")
def getExhibitionTimeNC(exhname):
    if exhname == "":
        exhname = context_manager.get_param("exhibitiondetail", "p_exhname")
    exhtime = getExhTime(exhname).lower()
    speech = "Sure, the duration of %s is %s." % (exhname, exhtime)
    exhnameabbr = abbrName(exhname)
    suggest1 = exhnameabbr+" content"
    suggest2 = exhnameabbr+" location"
    suggest3 = exhnameabbr + " ticket"
    context_manager.set("exhibitiondetail", "p_exhname", exhname)
    return ask(speech).suggest(suggest1, suggest2, suggest3)


@assist.action("getExhibitionLocation")
def getExhibitionLocation(exhname):
    if exhname == "":
        exhname = context_manager.get_param("exhibitiondetail", "p_exhname")
    exhlocation = getExhLocation(exhname)
    speech = "Let mini museum check...Find it! The location and open time of %s is %s. And you can get the museum map by click the chips below." % (exhname, exhlocation)

    exhnameabbr = abbrName(exhname)
    suggest2 = exhnameabbr+" time"
    suggest3 = exhnameabbr + " ticket"

    resp = ask(speech)
    resp.link_out('museum guide', 'https://www.nationalmuseum.sg/-/media/nms2017/documents/visitor-information/museum-guide/newenglish_jun_lowresforviewonly.pdf')
    resp.suggest(suggest2, suggest3)
    context_manager.set("exhibitiondetail", "p_exhname", exhname)
    return resp

@assist.action("getExhibitionLocationNC")
def getExhibitionLocationNC(exhname):
    if exhname == "":
        exhname = context_manager.get_param("exhibitiondetail", "p_exhname")
    exhlocation = getExhLocation(exhname)
    speech = "Let mini museum check...Find it! The location and open time of %s is %s. And you can get the museum map by click the chips below." % (exhname, exhlocation)

    exhnameabbr = abbrName(exhname)
    suggest2 = exhnameabbr+" time"
    suggest3 = exhnameabbr + " ticket"

    resp = ask(speech)
    resp.link_out('museum guide', 'https://www.nationalmuseum.sg/-/media/nms2017/documents/visitor-information/museum-guide/newenglish_jun_lowresforviewonly.pdf')
    resp.suggest(suggest2, suggest3)
    context_manager.set("exhibitiondetail", "p_exhname", exhname)
    return resp

@assist.action("getExhibitionTicket")
def getExhibitionTicket(exhname):
    if exhname == "":
        exhname = context_manager.get_param("exhibitiondetail", "p_exhname")
    exhTicket = getExhTicket(exhname)
    speech = "Let mini museum check... as for ticket, the %s is %s." % (exhname, exhTicket)
    exhnameabbr = abbrName(exhname)
    suggest1 = exhnameabbr+" content"
    suggest2 = exhnameabbr+" time"
    suggest3 = exhnameabbr + " location"
    context_manager.set("exhibitiondetail", "p_exhname", exhname)
    return ask(speech).suggest(suggest1, suggest2, suggest3)

@assist.action("getExhibitionTicketNC")
def getExhibitionTicketNC(exhname):
    if exhname == "":
        exhname = context_manager.get_param("exhibitiondetail", "p_exhname")
    exhTicket = getExhTicket(exhname)
    speech = "Let mini museum check... as for ticket, the %s is %s." % (exhname, exhTicket)
    exhnameabbr = abbrName(exhname)
    suggest1 = exhnameabbr+" content"
    suggest2 = exhnameabbr+" time"
    suggest3 = exhnameabbr + " location"
    context_manager.set("exhibitiondetail", "p_exhname", exhname)
    return ask(speech).suggest(suggest1, suggest2, suggest3)

@assist.action("getProgrammeIntro")
def getProgrammeIntro():
    pgmlist, pgmimagelist = getPgmIntro()
    resp = ask(
        "Sure, there are many interesting programmes in our museum, mini museum find a list for you:").build_carousel()
    number = len(pgmlist)
    for i in range(0, number):
        resp.add_item(title=pgmlist[i],
                      key=pgmlist[i],
                      img_url=pgmimagelist[i],
                      description=" ",
                      synonyms=[pgmlist[i]])
    return resp


@assist.action("getProgrammeContent")
def getProgrammeContent(pgmname):
    if pgmname == "":
        pgmname = context_manager.get('programme_tap').get('OPTION')
    pgmContent, pgmimage, pgmlink = getPgmContent(pgmname)
    speech = "You want know more about this Programme?Sure, mini museum found details about %s for you:" % pgmname
    resp = ask(speech)
    resp.card(text=pgmContent,
              title=pgmname,
              img_url=pgmimage,
              link=pgmlink,
              link_title="click for more details"
              )

    pgmnameabbr = abbrName(pgmname)
    suggest1 = pgmnameabbr+" time"
    suggest2 = pgmnameabbr+" location"
    suggest3 = pgmnameabbr + " ticket"
    context_manager.set("programmedetail", "p_pgmname", pgmname)
    return resp.suggest(suggest1, suggest2, suggest3)


@assist.action("getProgrammeTime")
def getProgrammeTime(pgmname):
    if pgmname == "":
        pgmname = context_manager.get_param('programmedetail', 'p_pgmname')
    pgmtime = getPgmTime(pgmname).lower()
    speech = "Mini museum found that the duration of %s is %s." % (pgmname, pgmtime)
    pgmnameabbr = abbrName(pgmname)
    suggest1 = pgmnameabbr+" content"
    suggest2 = pgmnameabbr+" location"
    suggest3 = pgmnameabbr + " ticket"
    context_manager.set("programmedetail", "p_pgmname", pgmname)
    return ask(speech).suggest(suggest1, suggest2, suggest3)

@assist.action("getProgrammeTimeNC")
def getProgrammeTimeNC(pgmname):
    if pgmname == "":
        pgmname = context_manager.get_param('programmedetail', 'p_pgmname')
    pgmtime = getPgmTime(pgmname).lower()
    speech = "Mini museum found that the duration of %s is %s." % (pgmname, pgmtime)
    pgmnameabbr = abbrName(pgmname)
    suggest1 = pgmnameabbr+" content"
    suggest2 = pgmnameabbr+" location"
    suggest3 = pgmnameabbr + " ticket"
    context_manager.set("programmedetail", "p_pgmname", pgmname)
    return ask(speech).suggest(suggest1, suggest2, suggest3)

@assist.action("getProgrammeLocation")
def getProgrammeLocation(pgmname):
    if pgmname == "":
        pgmname = context_manager.get_param('programmedetail', 'p_pgmname')
    pgmlocation, pgmimage, pgmlink = getPgmLocation(pgmname)
    speech="Let mini museum check...Got it! The location and open time is showing below, and you can get the museum map by click the chips below"
    loclist=pgmlocation.split(':;')

    resp=ask(speech)
    resp.card(text='  \n'.join(loclist),
              title=pgmname,
              link=pgmlink,
              link_title="click for more details"
              )

    resp.link_out('museum guide','https://www.nationalmuseum.sg/-/media/nms2017/documents/visitor-information/museum-guide/newenglish_jun_lowresforviewonly.pdf')
    pgmnameabbr=abbrName(pgmname)
    suggest2=pgmnameabbr+" time"
    suggest3 = pgmnameabbr + " ticket"
    resp.suggest(suggest2,suggest3)
    return resp

@assist.action("getProgrammeLocationNC")
def getProgrammeLocationNC(pgmname):
    if pgmname == "":
        pgmname = context_manager.get_param('programmedetail', 'p_pgmname')
    pgmlocation, pgmimage, pgmlink = getPgmLocation(pgmname)
    speech="Let mini museum check...Got it! The location and open time is showing below, and you can get the museum map by click the chips below"
    loclist=pgmlocation.split(':;')

    resp=ask(speech)
    resp.card(text='  \n'.join(loclist),
              title=pgmname,
              link=pgmlink,
              link_title="click for more details"
              )

    resp.link_out('museum guide','https://www.nationalmuseum.sg/-/media/nms2017/documents/visitor-information/museum-guide/newenglish_jun_lowresforviewonly.pdf')
    pgmnameabbr=abbrName(pgmname)
    suggest2=pgmnameabbr+" time"
    suggest3 = pgmnameabbr + " ticket"
    resp.suggest(suggest2,suggest3)
    return resp


@assist.action("getProgrammeTicket")
def getProgrammeTicket(pgmname):
    if pgmname == "":
        pgmname = context_manager.get_param('programmedetail', 'p_pgmname')
    pgmTicket = getPgmTicket(pgmname)
    speech = "The %s is %s." % (pgmname, pgmTicket)

    pgmnameabbr = abbrName(pgmname)
    suggest1 = pgmnameabbr+" content"
    suggest2 = pgmnameabbr+" time"
    suggest3 = pgmnameabbr + " location"
    context_manager.set("programmedetail", "p_pgmname", pgmname)
    return ask(speech).suggest(suggest1, suggest2, suggest3)

@assist.action("getProgrammeTicketNC")
def getProgrammeTicketNC(pgmname):
    if pgmname == "":
        pgmname = context_manager.get_param('programmedetail', 'p_pgmname')
    pgmTicket = getPgmTicket(pgmname)
    speech = "The %s is %s." % (pgmname, pgmTicket)

    pgmnameabbr = abbrName(pgmname)
    suggest1 = pgmnameabbr+" content"
    suggest2 = pgmnameabbr+" time"
    suggest3 = pgmnameabbr + " location"
    context_manager.set("programmedetail", "p_pgmname", pgmname)
    return ask(speech).suggest(suggest1, suggest2, suggest3)


@assist.action("getDiningIntro")
def getDiningIntro():
    dinlist, dinimagelist = getDinIntro()

    resp = ask(
        "Mmmm, there are many restaurants for you to choose in our museum, mini museum found a restaurant list for you:").build_carousel()
    number = len(dinlist)
    for i in range(0, number):
        resp.add_item(dinlist[i],
                      key=dinlist[i],
                      img_url=dinimagelist[i],
                      description=" ",)

    return resp


@assist.action("getDiningContent")
def getDiningContent(dinname):
    if dinname == "":
        dinname = context_manager.get('dining_tap').get('OPTION')
    dinContent, dinimage, dinlink = getDinContent(dinname)
    speech = "The information about %s is showing below:" % dinname
    resp = ask(speech)
    resp.card(text=dinContent,
              title=dinname,
              img_url=dinimage,
              link=dinlink,
              link_title="click for more details"
              )

    dinnameabbr = abbrName(dinname)
    context_manager.set("diningdetail", "p_dinname", dinname)
    suggest1 = dinnameabbr+" time"

    return resp.suggest(suggest1)


@assist.action("getDiningTime")
def getDiningTime(dinname):
    if dinname == "":
        dinname = context_manager.get_param('diningdetail', 'p_dinname')
    dintime = getDinTime(dinname).lower()
    speech = "The duration of %s is %s." % (dinname, dintime)

    dinnameabbr = abbrName(dinname)
    suggest1 = dinnameabbr+" content"
    context_manager.set("diningdetail", "dinname", dinname)
    return ask(speech).suggest(suggest1)

@assist.action("getDiningTimeNC")
def getDiningTimeNC(dinname):
    if dinname == "":
        dinname = context_manager.get_param('diningdetail', 'p_dinname')
    dintime = getDinTime(dinname).lower()
    speech = "The duration of %s is %s." % (dinname, dintime)

    dinnameabbr = abbrName(dinname)
    suggest1 = dinnameabbr+" content"
    context_manager.set("diningdetail", "dinname", dinname)
    return ask(speech).suggest(suggest1)

@assist.action("getRetailIntro")
def getRetailIntro():
    rtllist = getRtlIntro()[0]
    speech = "The National Museum of Singapore has one retail store named %s" % rtllist

    rtlnameabbr = abbrName(rtllist)
    suggest1 = rtlnameabbr+" content"
    suggest2 = rtlnameabbr+" time"
    return ask(speech).suggest(suggest1, suggest2)


@assist.action("getRetailContent")
def getRetailContent(rtlname):
    rtlContent, rtlimage, rtllink = getRtlContent(rtlname)
    speech = "The information about %s is showing below:" % rtlname
    resp = ask(speech)
    resp.card(text=rtlContent,
              title=rtlname,
              img_url=rtlimage,
              link=rtllink,
              link_title="click for more details"
              )

    rtlnameabbr = abbrName(rtlname)
    suggest1 = rtlnameabbr+" time"
    context_manager.set('retaildetail', 'p_rtlname', rtlname)
    return resp.suggest(suggest1)


@assist.action("getRetailTime")
def getRetailTime(rtlname):
    if rtlname == "":
        rtlname = context_manager.get_param('retaildetail', 'p_rtlname')
    rtltime = getRtlTime(rtlname).lower()
    speech = "The duration of %s is %s." % (rtlname, rtltime)

    rtlnameabbr = abbrName(rtlname)
    suggest1 = rtlnameabbr+" content"
    context_manager.set('retaildetail', 'rtlname', rtlname)
    return ask(speech).suggest(suggest1)

@assist.action("getRetailTimeNC")
def getRetailTimeNC(rtlname):
    if rtlname == "":
        rtlname = context_manager.get_param('retaildetail', 'p_rtlname')
    rtltime = getRtlTime(rtlname).lower()
    speech = "The duration of %s is %s." % (rtlname, rtltime)

    rtlnameabbr = abbrName(rtlname)
    suggest1 = rtlnameabbr+" content"
    context_manager.set('retaildetail', 'rtlname', rtlname)
    return ask(speech).suggest(suggest1)


@assist.action("getAction_intent_option_handler")
def getAction_intent_option_handler():
    option = context_manager.get('actions_intent_option').get('OPTION')
    if isExhExist(option):
        return event("exhibition_tap", OPTION=option)
    elif isPgmExist(option):
        return event("programme_tap", OPTION=option)
    elif isDinExist(option):
        return event("dining_tap", OPTION=option)


if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True, port=5000)
