#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   MuseumDeail.py
@Time    :   2019/08/08 12:46:30
@Author  :   XU JIACHEN 
@Version :   1.0
@Contact :   e0402032@u.nus.edu liyingxujiachen@gmail.com
@Desc    :   get all data about museum basic information
'''
# here put the import lib
from .utils.ExcelUtils import read_excel
from flask_assistant import ask, tell, event, build_item
from .utils.TableCard import tableCard,table

DATA_FILE = "./data/museum_data_last.xls"


def getMuseumIntroDao(museum):
    """
    desc :
    param :
    return :
    """
    TOPIC = "introduction"
    data = read_excel(DATA_FILE, "museum")
    intro_description = data.loc[data['topic'] == TOPIC][["description"]].iloc[0,0]
    intro_title = data.loc[data['topic'] == TOPIC][["title"]].iloc[0,0]
    intro_image = data.loc[data['topic'] == TOPIC][["image"]].iloc[0,0]
    link = data.loc[data['topic'] == TOPIC][["url"]].iloc[0,0]
    response = ask("Sure, this is the introduction of our museum")
    response.card(text=intro_description,
              title=intro_title,
              img_url=intro_image,
              link_title="Read More",
              link=link
              )
    response.suggest("Museum Open time", "Museum Location", "Museum Tickets")
    return response

def getMuseumOpenTimeDao(museum,time):
    """
    desc :
    param :
    return :
    """
    TOPIC = "opentime"
    data = read_excel(DATA_FILE, "museum")
    opentime_description = data.loc[data['topic'] == TOPIC][["description"]].iloc[0,0]
    opentime_title = data.loc[data['topic'] == TOPIC][["title"]].iloc[0,0]
    opentime_link = data.loc[data['topic'] == TOPIC][["url"]].iloc[0,0]
    response = ask("Sure, this is open time information of our museum")
    response.card(text=opentime_description.replace(";","  \n"),
              title=opentime_title,
              link_title="click for more details",
              link=opentime_link
              )
    response.suggest("Museum Open time", "Museum Location", "Museum Tickets")
    return response

def getMuseumLocationDao(museum,location):
    """
    desc :
    param :
    return :
    """
    TOPIC = "location"
    data = read_excel(DATA_FILE, "museum")
    location_description = data.loc[data['topic'] == TOPIC][["description"]].iloc[0,0]
    location_title = data.loc[data['topic'] == TOPIC][["title"]].iloc[0,0]
    location_image = data.loc[data['topic'] == TOPIC][["image"]].iloc[0,0]
    location_link = data.loc[data['topic'] == TOPIC][["url"]].iloc[0,0]
    response = ask("Sure, the location of our museum")
    response.card(text=location_description.replace(";","  \n"),
              title=location_title,
              link_title="Google Map",
              img_url=location_image,
              link=location_link
              )
    response.suggest("Museum Open time", "Museum Location", "Museum Tickets")
    return response

def getMuseumTicketInfoDao(museum,price):
    """
    desc :
    param :
    return :
    """
    TOPIC = "ticket"
    data = read_excel(DATA_FILE, "museum")
    ticketTable = table()
    ticketTable.add_columns([{"header":"Tourist Type","horizontalAlignment": "LEADING"},
                            {"header":"Fee","horizontalAlignment": "LEADING"}])
    tickets_info = data.loc[data['topic'] == TOPIC][["description"]].iloc[0,0]
    tickets_title = data.loc[data['topic'] == TOPIC][["title"]].iloc[0,0]
    tickets_link = data.loc[data['topic'] == TOPIC][["url"]].iloc[0,0]
    tourist_type_array = tickets_info.split("/")
    for _tourist_type in tourist_type_array:
        _temp = _tourist_type.split(":")
        ticketTable.add_row([{"text":_temp[0].replace(";","\n")},{"text":_temp[1].replace(";","\n")}])
    response = ask("Sure, the admission fees of our museum")
    response = tableCard(response,
                title=tickets_title.split("/")[0],
                subtitle=tickets_title.split("/")[1].replace(";","\n"),
                rows=ticketTable.rows,
                columns=ticketTable.columns,
                link=tickets_link,
                link_title="click for more details"
               )
    response.suggest("Museum Open time", "Museum Location", "Museum Tickets")
    return response

def getMuseumGuidedTourInfoDao(museum,guidedtours):
    """
    desc :
    param :
    return :
    """
    TOPIC = "guidedtours"
    data = read_excel(DATA_FILE, "museum")
    guidedtour_description = data.loc[data['topic'] == TOPIC][["description"]].iloc[0,0]
    guidedtour_title = data.loc[data['topic'] == TOPIC][["title"]].iloc[0,0]
    guidedtour_image = data.loc[data['topic'] == TOPIC][["image"]].iloc[0,0]
    guidedtour_link = data.loc[data['topic'] == TOPIC][["url"]].iloc[0,0]
    response = ask("Sure, the Guided Tours of our museum")
    response.card(
                text=guidedtour_description,
                title=guidedtour_title,
                link_title="Read More",
                img_url=guidedtour_image,
                link=guidedtour_link
            )
    return response

def getMuseumGroupVisitsDao(museum,groupvisits):
    """
    desc :
    param :
    return :
    """
    TOPIC = "groupvisits"
    data = read_excel(DATA_FILE, "museum")
    groupvisits_description = data.loc[data['topic'] == TOPIC][["description"]].iloc[0,0]
    groupvisits_title = data.loc[data['topic'] == TOPIC][["title"]].iloc[0,0]
    groupvisits_image = data.loc[data['topic'] == TOPIC][["image"]].iloc[0,0]
    groupvisits_link = data.loc[data['topic'] == TOPIC][["url"]].iloc[0,0]
    response = ask("Sure, the Group Visits of our museum")
    response.card(
                text=groupvisits_description,
                title=groupvisits_title,
                link_title="Read More",
                img_url=groupvisits_image,
                link=groupvisits_link
            )
    return response

def getMuseumAmenitiesandEtiquetteInfoDao(museum,amenities):
    """
    desc :
    param :
    return :
    """
    TOPIC_a = "amenities"
    TOPIC = TOPIC_a
    TOPIC_e = "etiquette"
    import difflib
    if difflib.SequenceMatcher(None, amenities, TOPIC_a).quick_ratio() > \
            difflib.SequenceMatcher(None, amenities, TOPIC_e).quick_ratio():
        TOPIC = TOPIC_a
    else:
        TOPIC = TOPIC_e
    data = read_excel(DATA_FILE, "museum")
    aande_info = data.loc[data['topic'] == TOPIC][["description"]].iloc[0,0]
    aande_title = data.loc[data['topic'] == TOPIC][["title"]].iloc[0,0]
    aande_image = data.loc[data['topic'] == TOPIC][["image"]].iloc[0,0]
    aande_link = data.loc[data['topic'] == TOPIC][["url"]].iloc[0,0]
    response = ask("Sure, the "+aande_title+"of our museum")
    response.card(
                text=aande_info.replace(";","  \n"),
                title=aande_title,
                link_title="Detail",
                img_url=aande_image,
                link=aande_link
            )
    return response

def getMuseumVenueRentalInfoDao(museum,venuerental):
    """
    desc :
    param :
    return :
    """
    TOPIC = "venuerental"
    data = read_excel(DATA_FILE, "museum")
    venuerental_info = data.loc[data['topic'] == TOPIC][["description"]].iloc[0,0]
    venuerental_title = data.loc[data['topic'] == TOPIC][["title"]].iloc[0,0]
    venuerental_notes = data.loc[data['topic'] == TOPIC][["notes"]].iloc[0,0]
    venuerental_image = data.loc[data['topic'] == TOPIC][["image"]].iloc[0,0]
    venuerental_link = data.loc[data['topic'] == TOPIC][["url"]].iloc[0,0]
    response = ask("Sure, the Venue Rental of our museum")
    response.card(
                text=venuerental_info+"  \n  \n"+venuerental_notes.replace("/","  \n"),
                title=venuerental_title,
                link_title="Read More",
                img_url=venuerental_image,
                link=venuerental_link,
            )
    return response

def getMuseumAccessibilityInfoDao(museum,accessibility):
    """
    desc :
    param :
    return :
    """
    TOPIC = "accessibility"
    data = read_excel(DATA_FILE, "museum")
    accessibility_info = data.loc[data['topic'] == TOPIC][["description"]].iloc[0,0]
    accessibility_title = data.loc[data['topic'] == TOPIC][["title"]].iloc[0,0]
    accessibility_image = data.loc[data['topic'] == TOPIC][["image"]].iloc[0,0]
    accessibility_link = data.loc[data['topic'] == TOPIC][["url"]].iloc[0,0]
    response = ask("Sure, the Accessibility Info of our museum")
    response.card(
                text=accessibility_info,
                title=accessibility_title,
                link_title="Detail",
                img_url=accessibility_image,
                link=accessibility_link
            )
    return response

def getMuseumPhotographyAndFilmingInfoDao(museum,photography):
    """
    desc :
    param :
    return :
    """
    TOPIC = "photography"
    data = read_excel(DATA_FILE, "museum")
    pandf_info = data.loc[data['topic'] == TOPIC][["description"]].iloc[0,0]
    pandf_info_title = data.loc[data['topic'] == TOPIC][["title"]].iloc[0,0]
    pandf_info_image = data.loc[data['topic'] == TOPIC][["image"]].iloc[0,0]
    pandf_info_link = data.loc[data['topic'] == TOPIC][["url"]].iloc[0,0]
    response = ask("Sure, the Photography And Filming Info of our museum")
    response.card(
                text=pandf_info,
                title=pandf_info_title,
                link_title="Detail",
                img_url=pandf_info_image,
                link=pandf_info_link
            )
    return response
    
# if __name__ == "__main__":
#     getMuseumOpenTimeDao("123","123")

