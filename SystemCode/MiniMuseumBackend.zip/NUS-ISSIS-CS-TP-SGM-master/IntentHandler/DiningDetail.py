#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@Time    :   2019/08/08 12:46:30
@Author  :   LI XINLIN
@Version :   1.0
@Contact :   e0402076@u.nus.edu
@Desc    :
'''
# here put the import lib
from IntentHandler.utils.ExcelUtils import read_excel
import pandas as pd

DATA_FILE = "./data/museum_data_last.xls"
DIN_DF=read_excel(DATA_FILE, "dining")


def getDinIntro():
    """
    desc : get all restaurants' name
    param :null
    return :the list of restaurants' name
    """

    dinlist=DIN_DF['title'].values.tolist()
    dinimagelist=DIN_DF['image'].values.tolist()
    return dinlist,dinimagelist

def isDinExist(dinname):
    _temp = DIN_DF[DIN_DF['title'] == dinname]
    if _temp.empty:
        return False
    else:
        return True

def getDinContent(dinname):
    """
    desc :get the content of a specific restaurant
    param :the name of the specific restaurant
    return :the content of the specific restaurant
    """

    dincontent=DIN_DF[DIN_DF['title']==dinname]['content'].values[0]
    dinimage=DIN_DF[DIN_DF['title']==dinname]['image'].values[0]
    dinlink=DIN_DF[DIN_DF['title']==dinname]['url'].values[0]
    return dincontent,dinimage,dinlink

def getDinTime(dinname):
    """
    desc :get the time of a specific restaurant
    param :the name of the specific restaurant
    return :the duration of the specific restaurant
    """

    dintime=DIN_DF[DIN_DF['title']==dinname]['time'].values[0]
    return dintime

if __name__ == "__main__":
    getDinIntro()
    getDinTime("Janice Wong Singapore [CLOSED PERMANENTLY]")
    getDinContent("Food for Thought")