#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   RecommendActivity.py
@Time    :   2019/08/11 21:19:27
@Author  :   XU JIACHEN 
@Version :   1.0
@Contact :   e0402032@u.nus.edu liyingxujiachen@gmail.com
@Desc    :   None
'''

# here put the import lib
from .utils.ExcelUtils import read_excel
from flask_assistant import ask, tell, event, build_item
from .utils.TableCard import tableCard,table
from dateutil.parser import parse
from .utils.TimeUtil import getAvailableDataPeriod,date2str
import json

DATA_FILE = "./data/museum_data_last.xls"

def getRecommonendList(recommendGroupType=None,recommendActivityType=None,date_period=None,date=None,price=None):
    """
    desc :
    param :
    return :
    """
    activities = []
    _exhibitions = []
    _programmes = []
    if recommendGroupType:
        data_exhibitions = read_excel(DATA_FILE, "exhibitions")
        _exhibitions = data_exhibitions.loc[data_exhibitions[recommendGroupType] == 1]
        data_programmes = read_excel(DATA_FILE, "programmes")
        _programmes = data_programmes.loc[data_programmes[recommendGroupType] == 1]
    elif recommendActivityType:
        data_exhibitions = read_excel(DATA_FILE, "exhibitions")
        _exhibitions = data_exhibitions.loc[data_exhibitions[recommendActivityType] == 1]
        data_programmes = read_excel(DATA_FILE, "programmes")
        _programmes = data_programmes.loc[data_programmes[recommendActivityType] == 1]
    if price:
        _exhibitions = _exhibitions.loc[_exhibitions['price'].str.lower().str.contains("free")]
        _programmes = _programmes.loc[_programmes['price'].str.lower().str.contains("free")]
    if date_period:
        _exhibitions = json.loads(_exhibitions[["title","startdate","enddate","image","price","url"]].to_json(orient='records'))
        _programmes = json.loads(_programmes[["title","startdate","enddate","image","price","url"]].to_json(orient='records'))
        _startdate = parse(date_period['startDate'])
        _enddate = parse(date_period['endDate'])
        _temp_exh = []
        _temp_pro = []
        for _exh in _exhibitions:
            if _exh['startdate'] != 'PERMANENT':
                sdate,edate = getAvailableDataPeriod(_startdate,_enddate,parse(_exh['startdate']),parse(_exh['enddate']))
                if sdate and edate:
                    _exh["availableDates"] = date2str(sdate) + " to " + date2str(edate)
                    _temp_exh.append(_exh)
            else:
                _exh["availableDates"] = date2str(_startdate) + " to " + date2str(_enddate)
                _temp_exh.append(_exh)
        for _prg in _programmes:
            if _prg['startdate'] != 'PERMANENT':
                sdate,edate = getAvailableDataPeriod(_startdate,_enddate,parse(_prg['startdate']),parse(_prg['enddate']))
                if sdate and edate:
                    _prg["availableDates"] = date2str(sdate) + " to " + date2str(edate)
                    _temp_pro.append(_prg)
            else:
                _exh["availableDates"] = date2str(_startdate) + " to " + date2str(_enddate)
                _temp_pro.append(_prg)
    if date:
        _exhibitions = json.loads(_exhibitions[["title","startdate","enddate","image","price","url"]].to_json(orient='records'))
        _programmes = json.loads(_programmes[["title","startdate","enddate","image","price","url"]].to_json(orient='records'))
        _startdate = parse(date)
        _enddate = parse(date)
        _temp_exh = []
        _temp_pro = []
        for _exh in _exhibitions:
            if _exh['startdate'] != 'PERMANENT':
                sdate,edate = getAvailableDataPeriod(_startdate,_enddate,parse(_exh['startdate']),parse(_exh['enddate']))
                if sdate and edate:
                    _exh["availableDates"] = date2str(sdate)
                    _temp_exh.append(_exh)
            else:
                _exh["availableDates"] = date2str(_startdate)
                _temp_exh.append(_exh)
        for _prg in _programmes:
            if _prg['startdate'] != 'PERMANENT':
                sdate,edate = getAvailableDataPeriod(_startdate,_enddate,parse(_prg['startdate']),parse(_prg['enddate']))
                if sdate and edate:
                    _prg["availableDates"] = date2str(sdate)
                    _temp_pro.append(_prg)
            else:
                _exh["availableDates"] = date2str(_startdate)
                _temp_pro.append(_prg)
    activities.extend(_temp_exh[:3])
    activities.extend(_temp_pro[:3])
    resp = ask("There are the Recommend Activities")
    mylist = resp.build_list("Recommend List")
    # Create a list with a title and assign to variable
    # mylist = resp.build_list("Question")
    for activity in activities:
        mylist.add_item(activity["title"],
                  key=activity["title"],
                  description=activity["availableDates"]+" is available. \nPrice: "+activity["price"][:25],
                  img_url=activity["image"])
    return mylist

    

    