#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   SupportDetail.py
@Time    :   2019/08/08 19:52:56
@Author  :   XU JIACHEN 
@Version :   1.0
@Contact :   e0402032@u.nus.edu liyingxujiachen@gmail.com
@Desc    :   None
'''

# here put the import lib
from .utils.ExcelUtils import read_excel
from flask_assistant import ask, tell, event, build_item

DATA_FILE = "./data/museum_data_last.xls"
def getSupportDetailDao(support,supporttype):
    """
    desc :
    param :
    return :
    """
    data = read_excel(DATA_FILE, "support")
    support = data.loc[data['title'].str.lower().str.contains(supporttype)]
    support_description = support[["content"]].iloc[0,0]
    support_title = support[["title"]].iloc[0,0]
    support_image = support[["image"]].iloc[0,0]
    support_link = support[["url"]].iloc[0,0]
    response = ask("Sure, the "+support_title+" Info of our museum")
    response.card(
                text=support_description,
                title=support_title,
                link_title="Detail",
                img_url=support_image,
                link=support_link
            )
    return response

def getVolunteerInfoDao(volunteer):
    """
    desc :
    param :
    return :
    """
    data = read_excel(DATA_FILE, "support")
    volunteer_data = data.loc[data['title'].str.lower().str.contains(volunteer)]
    if volunteer_data.shape[0] == 0:
        volunteer_data = data.loc[data['content'].str.contains(volunteer)]
    volunteer_description = volunteer_data[["content"]].iloc[0,0]
    volunteer_title = volunteer_data[["title"]].iloc[0,0]
    volunteer_image = volunteer_data[["image"]].iloc[0,0]
    volunteer_link = volunteer_data[["url"]].iloc[0,0]
    response = ask("Sure, the "+volunteer_title+" Info of our museum")
    response.card(
                text=volunteer_description,
                title=volunteer_title,
                link_title="Detail",
                img_url=volunteer_image,
                link=volunteer_link
            )
    return response

def getFellowshipInfoDao(fellowship):
    """
    desc :
    param :
    return :
    """
    data = read_excel(DATA_FILE, "support")
    fellowship_data = data.loc[data['title'].str.lower().str.contains(fellowship)]
    if fellowship_data.shape[0] == 0:
        fellowship_data = data.loc[data['content'].str.contains(fellowship)]
    fellowship_description = fellowship_data[["content"]].iloc[0,0]
    fellowship_title = fellowship_data[["title"]].iloc[0,0]
    fellowship_image = fellowship_data[["image"]].iloc[0,0]
    fellowship_link = fellowship_data[["url"]].iloc[0,0]
    response = ask("Sure, the "+fellowship_title+" Info of our museum")
    response.card(
                text=fellowship_description,
                title=fellowship_title,
                link_title="Detail",
                img_url=fellowship_image,
                link=fellowship_link
            )
    return response
