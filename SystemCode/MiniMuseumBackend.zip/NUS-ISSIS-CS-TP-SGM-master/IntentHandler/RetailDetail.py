#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@Time    :   2019/08/09 12:46:30
@Author  :   LI XINLIN
@Version :   1.0
@Contact :   e0402076@u.nus.edu
@Desc    :
'''
# here put the import lib
from IntentHandler.utils.ExcelUtils import read_excel
import pandas as pd

DATA_FILE = "./data/museum_data_last.xls"
RTL_DF=read_excel(DATA_FILE, "retail")


def getRtlIntro():
    """
    desc : get the introduction of retail branch
    param :null
    return :the introduction of retail branch
    """

    rtllist=RTL_DF["title"].values.tolist()
    return rtllist

def getRtlContent(rtlname):
    """
    desc :get the content of a specific retail store
    param :the name of the specific retail store
    return :the content of the specific retail store
    """

    rtlcontent=RTL_DF[RTL_DF['title']==rtlname]['content'].values[0]
    rtlimage=RTL_DF[RTL_DF['title']==rtlname]['image'].values[0]
    rtllink=RTL_DF[RTL_DF['title']==rtlname]['url'].values[0]
    return rtlcontent,rtlimage,rtllink

def getRtlTime(rtlname):
    """
    desc :get the time of a specific retail store
    param :the name of the specific retail store
    return :the duration of the specific retail store
    """

    rtltime=RTL_DF[RTL_DF['title']==rtlname]['time'].values[0]
    return rtltime

if __name__ == "__main__":
    getRtlIntro()
    getRtlTime("Museum Label")
    getRtlContent("Museum Label")