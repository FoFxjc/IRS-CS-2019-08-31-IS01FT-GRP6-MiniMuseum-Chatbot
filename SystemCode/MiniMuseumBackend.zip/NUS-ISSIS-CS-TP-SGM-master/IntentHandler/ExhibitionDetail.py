#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@Time    :   2019/08/08 12:46:30
@Author  :   LI XINLIN
@Version :   1.0
@Contact :   e0402076@u.nus.edu
@Desc    :
'''
# here put the import lib
from IntentHandler.utils.ExcelUtils import read_excel
import pandas as pd

DATA_FILE = "./data/museum_data_last.xls"
EXH_DF=read_excel(DATA_FILE, "exhibitions")


def getExhIntro():
    """
    desc : get all exhibitions' name
    param :null
    return :the list of exhibitions' name
    """

    exhlist=EXH_DF['title'].values.tolist()
    exhimagelist=EXH_DF['image'].values.tolist()
    return exhlist,exhimagelist

def isExhExist(exhname):
    _temp = EXH_DF[EXH_DF['title'] == exhname]
    if _temp.empty:
        return False
    else:
        return True


def getExhContent(exhname):
    """
    desc :get the content of a specific exhibition
    param :the name of the specific exhibition
    return :the content of the specific exhibition
    """

    exhcontent=EXH_DF[EXH_DF['title']==exhname]['content'].values[0]
    exhimage=EXH_DF[EXH_DF['title']==exhname]['image'].values[0]
    exhlink=EXH_DF[EXH_DF['title']==exhname]['url'].values[0]
    return exhcontent,exhimage,exhlink

def getExhTime(exhname):
    """
    desc :get the time of a specific exhibition
    param :the name of the specific exhibition
    return :the duration of the specific exhibition
    """

    exhstime=EXH_DF[EXH_DF['title']==exhname]['startdate'].values[0]
    exhetime=EXH_DF[EXH_DF['title']==exhname]['enddate'].values[0]
    if exhstime==exhetime:
        exhtime=exhstime
    else:
        exhtime=exhstime+'-'+exhetime
    return exhtime

def getExhLocation(exhname):
    """
    desc :get the location of a specific exhibition
    param :the name of the specific exhibition
    return :the location of the specific exhibition
    """

    exhlocation=EXH_DF[EXH_DF['title']==exhname]['location'].values[0]
    return exhlocation

def getExhTicket(exhname):
    """
    desc :get the ticket information of a specific exhibition
    param :the name of the specific exhibition
    return :the ticket information of the specific exhibition
    """

    exhTicket=EXH_DF[EXH_DF['title']==exhname]['price'].values[0]
    return exhTicket

if __name__ == "__main__":
    getExhIntro()
    getExhTime("Gallery 10")
    getExhLocation("Gallery 10")
    getExhTicket("Gallery 10")
    getExhContent("Gallery 10")