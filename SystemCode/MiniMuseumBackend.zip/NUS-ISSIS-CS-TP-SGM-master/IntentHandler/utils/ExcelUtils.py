#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   ExcelUtils.py
@Time    :   2019/08/08 12:49:37
@Author  :   XU JIACHEN 
@Version :   1.0
@Contact :   e0402032@u.nus.edu liyingxujiachen@gmail.com
@Desc    :   all opeartions to the excel file
'''

# here put the import lib
import pandas as pd
def read_excel(file_name,sheet_name=0):
    """
    desc : use pandas to read excel
    param : file_name the file name of excel file
            sheet_name  the name of wanted sheet
                        default 0 the first sheet
    return : pd.DataFrame
    """
    return pd.DataFrame(pd.read_excel(file_name,sheet_name=sheet_name))
