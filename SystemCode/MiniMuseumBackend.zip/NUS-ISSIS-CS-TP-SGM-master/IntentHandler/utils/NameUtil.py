#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@Time    :   2019/08/09 12:46:30
@Author  :   LI XINLIN
@Version :   1.0
@Contact :   e0402076@u.nus.edu
@Desc    :   cut the name of exhibitions,programmes,retail stores or restaurant into 13 characters,
             so it can be showed in the hint chip
'''
# here put the import lib

def abbrName(targetname):

    length=len(targetname)
    if length>13:
        targetabbr=targetname[:13]+"..."
    else:
        targetabbr=targetname

    return targetabbr