#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   TableCard.py
@Time    :   2019/08/09 14:34:57
@Author  :   XU JIACHEN 
@Version :   1.0
@Contact :   e0402032@u.nus.edu liyingxujiachen@gmail.com
@Desc    :   None
'''

# here put the import lib

def tableCard(
    response,
    title,
    rows,
    columns,
    img_url=None,
    img_alt=None,
    subtitle=None,
    link=None,
    link_title=None,
):
    card_payload = {"title": title, "subtitle": subtitle,"rows":rows,"columnProperties":columns}

    if link and link_title:
        btn_payload = [{"title": link_title, "openUriAction": {"uri": link}}]
        card_payload["buttons"] = btn_payload

    if img_url:
        img_payload = {"url": img_url, "accessibilityText": img_alt or img_url}
        card_payload["image"] = img_payload

    response._messages.append(
        {"platform": "ACTIONS_ON_GOOGLE", "tableCard": card_payload}
    )

    return response
        
class table():
    def __init__(self):
        self.rows = []
        self.columns = []

    def add_row(self,cells):
        row = {"dividerAfter": "false"}
        row["cells"] = cells
        self.rows.append(row)

    def add_columns(self,columns):
        self.columns=columns