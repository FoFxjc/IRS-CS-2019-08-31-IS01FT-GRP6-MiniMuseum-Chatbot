#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   TimeUtil.py
@Time    :   2019/08/12 15:55:04
@Author  :   XU JIACHEN 
@Version :   1.0
@Contact :   e0402032@u.nus.edu liyingxujiachen@gmail.com
@Desc    :   None
'''

# here put the import lib


import datetime
import time
from pytz import timezone

cst_tz = timezone('Asia/Shanghai')


def getAvailableDataPeriod(date_period_one_start, date_period_one_end, date_period_two_start, date_period_two_end):
    date_period_one_start = date_period_one_start.replace(tzinfo=cst_tz)
    date_period_one_end = date_period_one_end.replace(tzinfo=cst_tz)
    date_period_two_start = date_period_two_start.replace(tzinfo=cst_tz)
    date_period_two_end = date_period_two_end.replace(tzinfo=cst_tz)
    if ((date_period_one_start >= date_period_two_start and date_period_one_start <= date_period_two_end) or
            (date_period_one_end >= date_period_two_start and date_period_one_end <= date_period_two_end)):
            if date_period_one_start >= date_period_two_start:
                sblong = date_period_one_start 
            else: 
                sblong = date_period_two_start
            if date_period_two_end >= date_period_one_end: 
                eblong = date_period_one_end 
            else:
                eblong = date_period_two_end
            return sblong,eblong
    return None, None

def date2str(date,date_formate = "%Y-%m-%d"):
    str = date.strftime(date_formate)
    return str
