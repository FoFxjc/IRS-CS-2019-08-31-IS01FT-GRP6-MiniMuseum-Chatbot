#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@Time    :   2019/08/08 12:46:30
@Author  :   LI XINLIN
@Version :   1.0
@Contact :   e0402076@u.nus.edu
@Desc    :
'''
# here put the import lib
from IntentHandler.utils.ExcelUtils import read_excel
import pandas as pd

DATA_FILE = "./data/museum_data_last.xls"
PGM_DF=read_excel(DATA_FILE, "programmes")


def getPgmIntro():
    """
    desc : get all programmes' name
    param :null
    return :the list of programmes' name
    """

    pgmlist=PGM_DF['title'].values.tolist()
    pgmimagelist = PGM_DF['image'].values.tolist()
    return pgmlist,pgmimagelist

def isPgmExist(pgmname):
    _temp = PGM_DF[PGM_DF['title'] == pgmname]
    if _temp.empty:
        return False
    else:
        return True

def getPgmContent(pgmname):
    """
    desc :get the content of a specific programme
    param :the name of the specific programme
    return :the content of the specific programme
    """

    pgmcontent=PGM_DF[PGM_DF['title']==pgmname]['content'].values[0]
    pgmimage = PGM_DF[PGM_DF['title'] == pgmname]['image'].values[0]
    pgmlink=PGM_DF[PGM_DF['title'] == pgmname]['url'].values[0]
    return pgmcontent,pgmimage,pgmlink

def getPgmTime(pgmname):
    """
    desc :get the time of a specific programme
    param :the name of the specific programme
    return :the duration of the specific programme
    """

    pgmstime=PGM_DF[PGM_DF['title']==pgmname]['startdate'].values[0]
    pgmetime=PGM_DF[PGM_DF['title']==pgmname]['enddate'].values[0]
    if pgmstime==pgmetime:
        pgmtime=pgmstime
    else:
        pgmtime=pgmstime+'-'+pgmetime
    return pgmtime

def getPgmLocation(pgmname):
    """
    desc :get the location of a specific programme
    param :the name of the specific programme
    return :the location of the specific programme
    """
    pgmlocation=PGM_DF[PGM_DF['title']==pgmname]['location'].values[0]
    pgmimage = PGM_DF[PGM_DF['title'] == pgmname]['image'].values[0]
    pgmlink = PGM_DF[PGM_DF['title'] == pgmname]['url'].values[0]
    return pgmlocation,pgmimage,pgmlink

def getPgmTicket(pgmname):
    """
    desc :get the ticket information of a specific programme
    param :the name of the specific programme
    return :the ticket information of the specific programme
    """

    pgmTicket=PGM_DF[PGM_DF['title']==pgmname]['price'].values[0]
    return pgmTicket

if __name__ == "__main__":
    getPgmIntro()
    getPgmTime("National Day Open House")
    getPgmLocation("Family Fun at the National Museum")
    getPgmTicket("GosTan Back - A Time-travelling Adventure on Wheels by MySuperFuture Theatrical Productions")
    getPgmContent("National Day Open House")